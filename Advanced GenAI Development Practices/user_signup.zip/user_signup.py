import smtplib

def add_user_to_db(user_data, db_connection):
    # Add the user to the database
    cursor = db_connection.cursor()
    sql = f"INSERT INTO users (name, email) VALUES ('{user_data['name']}', '{user_data['email']}')"
    cursor.execute(sql)
    db_connection.commit()
    cursor.close()

def send_welcome_email(email_address):
    # Send a welcome email to the user
    sender = "admin@example.com"
    message = f"Subject: Welcome!\n\nThank you for signing up!"
    server = smtplib.SMTP('smtp.example.com')
    server.sendmail(sender, email_address, message)
    server.quit()

def signup(user_data, db_connection):
    add_user_to_db(user_data, db_connection)
    send_welcome_email(user_data['email'])