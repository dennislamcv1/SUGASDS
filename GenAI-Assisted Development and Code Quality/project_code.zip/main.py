def read_file(filename):
    file = open(filename)
    lines = file.readlines()
    file.close()
    return lines


def count_words(line):
    return len(line.split(" "))


def print_line_counts(lines):
    for i in range(len(lines)):
        count = count_words(lines[i])
        print(
            "Line " + str(i + 1) + ": " + lines[i].strip() + " - Words: " + str(count)
        )


def total_word_count(lines):
    total = 0
    for line in lines:
        total += count_words(line)
    print("Total words in file: " + str(total))
    return total


def average_words_per_line(lines):
    total = total_word_count(lines)
    avg = total / len(lines)
    print("Average words per line: " + str(avg))
    return avg


def find_longest_and_shortest_line(lines):
    max_len = 0
    min_len = 9999
    longest = ""
    shortest = ""
    for line in lines:
        words = count_words(line)
        if words > max_len:
            max_len = words
            longest = line
        if words < min_len:
            min_len = words
            shortest = line
    print("Longest line: " + longest.strip() + " (" + str(max_len) + " words)")
    print("Shortest line: " + shortest.strip() + " (" + str(min_len) + " words)")


def search_word(lines, word):
    count = 0
    for line in lines:
        count += line.lower().count(word.lower())
    print("The word '" + word + "' appears " + str(count) + " times.")


def export_results(lines):
    f = open("results.txt", "w")
    for i in range(len(lines)):
        f.write(
            "Line "
            + str(i + 1)
            + ": "
            + lines[i].strip()
            + " - Words: "
            + str(count_words(lines[i]))
            + "\n"
        )
    f.close()
    print("Results exported to results.txt")


def main():
    filename = "shakespeare.txt"
    lines = read_file(filename)
    print_line_counts(lines)
    total_word_count(lines)
    average_words_per_line(lines)
    find_longest_and_shortest_line(lines)
    search_word(lines, "to")
    export_results(lines)


if __name__ == "__main__":
    main()
